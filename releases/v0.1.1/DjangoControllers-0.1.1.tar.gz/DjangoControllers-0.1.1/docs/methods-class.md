# Methods Class

The Methods class is the key to the package. It supports by default the following request methods:
- GET
- POST
- PUT
- PATCH
- DELETE

However, you can pass additional kwargs to the constructor if you require a non standard method.
Additional methods should be upper case.